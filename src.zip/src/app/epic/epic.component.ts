import { Component } from '@angular/core';

@Component({
  selector: 'epic',
  templateUrl: './epic.component.html',
  styleUrls: ['./epic.component.css']
})
export class EpicComponent {

}
