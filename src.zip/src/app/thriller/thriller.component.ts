import { Component } from '@angular/core';

@Component({
  selector: 'thriller',
  templateUrl: './thriller.component.html',
  styleUrls: ['./thriller.component.css']
})
export class ThrillerComponent {

}
