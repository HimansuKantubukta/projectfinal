import { Component } from '@angular/core';

@Component({
  selector: 'horror',
  templateUrl: './horror.component.html',
  styleUrls: ['./horror.component.css']
})
export class HorrorComponent {

}
