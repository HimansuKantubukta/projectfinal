import { Component } from '@angular/core';

@Component({
  selector: 'adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent {

}
