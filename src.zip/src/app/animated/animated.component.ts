import { Component } from '@angular/core';

@Component({
  selector: 'animated',
  templateUrl: './animated.component.html',
  styleUrls: ['./animated.component.css']
})
export class AnimatedComponent {

}
